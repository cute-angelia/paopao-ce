package hash

import "testing"

func TestSha1(t *testing.T) {

}
