## V2

why v2 ?

[Strange behavior with TTL on reopen of (actively written) DB files. #85](https://github.com/tidwall/buntdb/issues/85)