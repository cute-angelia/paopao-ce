图片存储

1. 七牛
2. weibo
3. github