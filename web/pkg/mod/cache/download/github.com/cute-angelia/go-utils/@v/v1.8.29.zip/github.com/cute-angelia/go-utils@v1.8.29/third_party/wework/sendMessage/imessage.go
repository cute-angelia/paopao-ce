package sendMessage

type IMessage interface {
	GetMessage() []byte
}
