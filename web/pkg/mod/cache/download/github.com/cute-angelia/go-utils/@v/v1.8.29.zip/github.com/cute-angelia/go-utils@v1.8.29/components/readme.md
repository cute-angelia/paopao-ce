## 组件库

* 下载
* minio
* gorm 新版： igorm
* gorm 旧版： umysql


### k/v store db

1. ibitcake (市场很多基于bitcake的封装，比较厉害的库)
2. ibunt (对json数据索引友好，可以方便做排行榜等缓存，ttl有点问题，重启后时间不对)