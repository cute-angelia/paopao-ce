## 雪花优化算法

https://github.com/yitter/IdGenerator/