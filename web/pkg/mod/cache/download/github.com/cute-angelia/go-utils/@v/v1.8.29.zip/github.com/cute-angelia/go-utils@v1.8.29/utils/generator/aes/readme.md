
aes encode decode

[gist](https://gist.github.com/manishtpatel/8222606)

[play golang](https://play.golang.org/p/5G-IUlYqQV)