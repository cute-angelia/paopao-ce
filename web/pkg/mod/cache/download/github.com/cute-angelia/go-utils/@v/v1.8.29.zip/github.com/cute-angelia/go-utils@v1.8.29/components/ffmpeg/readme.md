命令参考

https://zhuanlan.zhihu.com/p/67878761