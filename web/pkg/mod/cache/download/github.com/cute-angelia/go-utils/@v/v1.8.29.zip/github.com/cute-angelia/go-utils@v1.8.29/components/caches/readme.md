## cache

like https://github.com/faabiosr/cachego support

[zero 的缓存设计](https://github.com/zeromicro/go-zero/blob/master/core/collection/cache.go)