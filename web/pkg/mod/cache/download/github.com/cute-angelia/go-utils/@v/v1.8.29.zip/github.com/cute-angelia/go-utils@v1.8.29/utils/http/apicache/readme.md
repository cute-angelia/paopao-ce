用于接口数据缓存

可以传递参数进行业务缓存



// use https://github.com/go-chi/stampede