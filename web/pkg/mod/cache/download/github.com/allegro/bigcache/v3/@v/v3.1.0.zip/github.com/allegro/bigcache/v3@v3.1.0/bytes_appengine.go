// +build appengine

package bigcache

func bytesToString(b []byte) string {
	return string(b)
}
