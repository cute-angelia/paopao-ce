package suite_command

func Tested() string {
	return "tested"
}

func Untested() string {
	return "untested"
}
