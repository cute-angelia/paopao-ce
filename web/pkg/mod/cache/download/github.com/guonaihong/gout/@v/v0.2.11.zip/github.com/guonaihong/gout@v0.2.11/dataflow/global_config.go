package dataflow

import (
	"github.com/guonaihong/gout/setting"
)

// 存放全局配置选项
var GlobalSetting = setting.Setting{
	NotIgnoreEmpty: true,
}
