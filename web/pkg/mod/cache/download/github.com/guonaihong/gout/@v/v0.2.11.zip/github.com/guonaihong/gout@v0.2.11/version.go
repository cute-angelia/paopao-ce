package gout

// Version show version
const Version = "v0.2.10"
