package gout

import (
	"github.com/guonaihong/gout/dataflow"
)

type Text struct {
	dataflow.DataFlow
}
