package core

type Need struct {
	Need interface{}
	Got  interface{}
}
