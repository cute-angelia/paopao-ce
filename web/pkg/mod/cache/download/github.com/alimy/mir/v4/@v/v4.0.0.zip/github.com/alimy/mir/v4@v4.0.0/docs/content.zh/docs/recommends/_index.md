---
weight: 3
bookFlatSection: true
title: "推荐项目"
---

- [Yesql](https://alimy.me/yesql) - 🔥一个用于使用[sqlx](https://github.com/jmoiron/sqlx)来开发数据业务逻辑的辅助库.
- [paopao-ce](https://github.com/rocboss/paopao-ce/tree/dev) - 🔥一个清新文艺的微社区.
