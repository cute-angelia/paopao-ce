# templates
use for generate interface's template.