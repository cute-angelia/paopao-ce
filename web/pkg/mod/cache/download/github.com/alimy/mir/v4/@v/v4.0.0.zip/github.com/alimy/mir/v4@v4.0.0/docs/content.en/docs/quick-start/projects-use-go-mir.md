---
title: "Projects That Use go-mir"
---

## Projects That Use go-mir
 * [examples](https://github.com/alimy/mir/tree/main/examples) - a demo example to describe how to use [Mir](https://github.com/alimy/mir) to develop RESTful API backend service quickly.
* [paopao-ce](https://github.com/rocboss/paopao-ce/tree/dev) - A artistic "twitter like" community built on gin+zinc+vue+ts.   
