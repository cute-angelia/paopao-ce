---
weight: 3
bookFlatSection: true
title: "Recommends"
---

- [Yesql](https://alimy.me/yesql) - 🔥a help tool for develop database logic that use [sqlx](https://github.com/jmoiron/sqlx).
- [paopao-ce](https://github.com/rocboss/paopao-ce/tree/dev) - 🔥an artistic "twitter like" community built on gin+zinc+vue+ts.
