---
title: "使用go-mir的项目"
---

## 使用go-mir的项目
* [examples](https://github.com/alimy/mir/tree/main/examples) - 本项目自带的demo，主要演示了如何使用[Mir](https://github.com/alimy/mir)快速进行RESTful API的后端开发。   
* [paopao-ce](https://github.com/rocboss/paopao-ce/tree/dev) - 一个清新文艺的微社区，提供类似Twiter/微博的推文分享服务。    
