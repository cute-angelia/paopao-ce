# Changelog

All notable changes to paopao-ce are documented in this file.
## 4.0.0 ([`dev`](https://github.com/alimy/mir))
### Added
- add `gin` engine support for go-mir v4
- add `chi` engine support for go-mir v4
- add `hertz` engine support for go-mir v4
- add `mux` engine support for go-mir v4
- add `httprouter` engine support for go-mir v4
- add `echo` engine support for go-mir v4
- add `iris` engine support for go-mir v4
- add `fiber` engine support for go-mir v4
- add `macaron` engine support for go-mir v4
- add `mirc` help tool for go-mir v4
