/*
Package repository: https://github.com/getsentry/sentry-go/

For more information about Sentry and SDK features, please have a look at the official documentation site: https://docs.sentry.io/platforms/go/
*/
package sentry
