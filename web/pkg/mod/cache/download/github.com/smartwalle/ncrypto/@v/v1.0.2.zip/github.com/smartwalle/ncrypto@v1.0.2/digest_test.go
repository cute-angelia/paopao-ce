package ncrypto_test

import (
	"testing"
)

func TestMD5(t *testing.T) {
}

func TestSHA1(t *testing.T) {
}

func TestSHA256(t *testing.T) {
}

func TestSHA512(t *testing.T) {
}
