package ngx

type Body Reader
